<?php
mysql_select_db('proj1',mysql_connect('localhost','admin','admin'))or die(mysql_error());
?>