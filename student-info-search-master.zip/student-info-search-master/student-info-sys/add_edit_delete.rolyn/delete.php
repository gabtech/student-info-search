<?php 

include('dbcon.php');

$get_id=$_GET['student_id'];

mysql_query("delete from bhup where student_id = '$get_id' ")or die(mysql_error());
header('location:index.php');
?>