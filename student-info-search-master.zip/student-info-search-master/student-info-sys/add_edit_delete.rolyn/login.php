<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<head>
  <title>Registration system PHP and MySQL</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="form-wrapper">	 
  <form method="post" action="login.php">
  <h3>Login</h3>
  	<?php include('errors.php'); ?>
    <div class="form-item">
  		<input type="text" name="username" placeholder="Username"></input>
  	</div>
  	
    <div class="form-item">
  		<input type="password" name="password" placeholder="Password"></input>
  	</div>
  	
    <div class="button-panel">
  		<button type="submit" class="button" name="login_user">Login</button>
  	</div>
  	<p>
  		Not yet an admin? <a href="register.php">Sign up</a>
  	</p>
  </form>
  </div>
</body>
</html>