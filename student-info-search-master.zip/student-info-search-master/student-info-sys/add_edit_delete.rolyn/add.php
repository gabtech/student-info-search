<?php
	include('dbcon.php');
							
							if (!isset($_FILES['image']['tmp_name'])) {
							echo "";
							}else{
							$file=$_FILES['image']['tmp_name'];
							$image = $_FILES["image"] ["name"];
							$image_name= addslashes($_FILES['image']['name']);
							$size = $_FILES["image"] ["size"];
							$error = $_FILES["image"] ["error"];

							if ($error > 0){
										die("Error uploading file! Code $error.");
									}else{
										if($size > 10000000) //conditions for the file
										{
										die("Format is not allowed or file size is too big!");
										}
										
									else
										{

									move_uploaded_file($_FILES["image"]["tmp_name"],"upload/" . $_FILES["image"]["name"]);			
									$location=$_FILES["image"]["name"];
									$fname= $_POST['fname'];
									$mname= $_POST['mname'];
									$lname= $_POST['lname'];
									$mn= $_POST['mn'];
									$school= $_POST['school'];
									$year= $_POST['year'];
									$dob= $_POST['dob'];
									$mail= $_POST['mail'];
									$phone= $_POST['phone'];

						mysql_query("insert into bhup (fname,mname,lname,mn,school,year,dob,mail,phone,location) 
						values('$fname','$mname','$lname','$mn','$school','$year','$dob','$mail','$phone','$location')")or die(mysql_error());
									
									}
										header('location:index.php');
									}
							}
?>								