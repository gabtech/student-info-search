	    <!-- Button to trigger modal -->
    <a class="btn btn-primary" href="#myModal" data-toggle="modal">Click Here To Add</a>
	<br>
	<br>
	<br>
    <!-- Modal -->
    <div id="myModal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-header">

    <h3 id="myModalLabel">Add</h3>
    </div>
    <div class="modal-body">
	
					<form method="post" action="add.php"  enctype="multipart/form-data">
					<table class="table1">
						<tr>
							<td><label style="color:#3a87ad; font-size:18px;">FirstName</label></td>
							<td width="30"></td>
							<td><input type="text" name="fname" placeholder="FirstName" required /></td>
						</tr>
						<tr>
							<td><label style="color:#3a87ad; font-size:18px;">MiddleName</label></td>
							<td width="30"></td>
							<td><input type="text" name="mname" placeholder="MiddleName" required /></td>
						</tr>
						<tr>
							<td><label style="color:#3a87ad; font-size:18px;">LastName</label></td>
							<td width="30"></td>
							<td><input type="text" name="lname" placeholder="LastName" required /></td>
						</tr>
						<tr>
							<td><label style="color:#3a87ad; font-size:18px;">Matric No</label></td>
							<td width="30"></td>
							<td><input type="text" name="mn" placeholder="Matric No" required /></td>
						</tr>
						<tr>
							<td><label style="color:#3a87ad; font-size:18px;">Institution</label></td>
							<td width="30"></td>
							<td><select name="school">
<option >Select School / Institution</option>
<option value="LAGOS STATE POLYTECHNIC">LAGOS STATE POLYTECHNIC</option>
<option value="YABA COLLEGE OF TECHNOLOGY">YABA COLLEGE OF TECHNOLOGY</option>
<option value="LAGOS STATE UNIVERSITY">LAGOS STATE UNIVERSITY</option>
<option value="UNIVERSITY OF LAGOS">UNIVERSITY OF LAGOS</option>
<option value="FEDERAL COLLEGE OF EDUCATION">FEDERAL COLLEGE OF EDUCATION</option>
</select></td>
						</tr>
						<tr>
							<td><label style="color:#3a87ad; font-size:18px;">Graduation Year</label></td>
							<td width="30"></td>
							<td><select name="year">
<option >select year</option>
	<option value="2015">2015</option>
	<option value="2014">2014</option>
	<option value="2013">2013</option>
	<option value="2012">2012</option>
	<option value="2011">2011</option>
	<option value="2010">2010</option>
	<option value="2009">2009</option>
	<option value="2008">2008</option>	
	<option value="2007">2007</option>
	<option value="2006">2006</option>
	<option value="2005">2005</option>
	<option value="2004">2004</option>
	<option value="2003">2003</option>
	<option value="2002">2002</option>
	<option value="2001">2001</option>
	<option value="2000">2000</option>
	<option value="1999">1999</option>
	<option value="1998">1998</option>
	<option value="1997">1997</option>
	<option value="1996">1996</option>
	<option value="1995">1995</option>
	<option value="1994">1994</option>
	<option value="1993">1993</option>
	<option value="1992">1992</option>
	<option value="1991">1991</option>
	<option value="1990">1990</option>
	<option value="1989">1989</option>
	<option value="1988">1988</option>
	<option value="1987">1987</option>
	<option value="1986">1986</option>
	<option value="1985">1985</option>
	<option value="1984">1984</option>
	<option value="1983">1983</option>
	<option value="1982">1982</option>
	<option value="1981">1981</option>
	<option value="1980">1980</option>
	<option value="1979">1979</option>
	<option value="1978">1978</option>
	<option value="1977">1977</option>
	<option value="1976">1976</option>
	<option value="1975">1975</option>
	<option value="1974">1974</option>
	<option value="1973">1973</option>
	<option value="1972">1972</option>
	<option value="1971">1971</option>
	<option value="1970">1970</option>
	<option value="1969">1969</option>
	<option value="1968">1968</option>
	<option value="1967">1967</option>
	<option value="1966">1966</option>
</select></td>
						</tr>
						<tr>
							<td><label style="color:#3a87ad; font-size:18px;">Birthday</label></td>
							<td width="30"></td>
							<td><input type="text" name="dob" placeholder="Birthday" required /></td>
						</tr>
						<tr>
							<td><label style="color:#3a87ad; font-size:18px;">Email</label></td>
							<td width="30"></td>
							<td><input type="email" name="mail" placeholder="Email" required /></td>
						</tr>																								
						<tr>
							<td><label style="color:#3a87ad; font-size:18px;">Phone</label></td>
							<td width="30"></td>
							<td><input type="text" name="phone" placeholder="Phone No" required /></td>
						</tr>
						<tr>
							<td><label style="color:#3a87ad; font-size:18px;">Image</label></td>
							<td width="30"></td>
							<td><input type="file" name="image" required /></td>
						</tr>
						
					</table>
					
	
    </div>
    <div class="modal-footer">
    <button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>
<button type="submit" name="Submit" class="btn btn-primary">Add</button>
    </div>
	

					</form>
    </div>			