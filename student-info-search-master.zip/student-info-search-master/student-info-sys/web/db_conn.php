<?php

$dbhost="localhost";
$dbuser="admin";
$dbpass="admin";
$dbname="proj1";
$conn=mysql_connect("$dbhost","$dbuser","$dbpass") or die("could not connect to mysql");

mysql_select_db($dbname,$conn);
?>