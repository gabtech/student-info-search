<?php
mysql_select_db('proj1',mysql_connect('localhost','gabtech','lab300'))or die(mysql_error());
?>