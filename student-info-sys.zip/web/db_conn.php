<?php

$dbhost="localhost";
$dbuser="gabtech";
$dbpass="lab300";
$dbname="proj1";
$conn=mysql_connect("$dbhost","$dbuser","$dbpass") or die("could not connect to mysql");

mysql_select_db($dbname,$conn);
?>