<!--
Author: Gswapps
Author URL: http://gswapps.com
License: Creative Commons Attribution
License URL: http://gabtechweb.com
-->
<!DOCTYPE html>
<html lang="zxx">

<head>
	<title>Best Study an Education Category Test run site</title>
	<!-- meta-tags -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Soft Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
	<script>
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!-- //meta-tags -->
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
	<!-- font-awesome -->
	<link href="css/font-awesome.css" rel="stylesheet">
	<!-- fonts -->
	<link href="//fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i"
	    rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">
</head>

<body>
	<!-- header -->
	<div class="header-top">
		<div class="container">
			<div class="bottom_header_left">
				<p>
					<span class="fa fa-map-marker" aria-hidden="true"></span>Nigeria
				</p>
			</div>
			<div class="bottom_header_right">
				<div class="bottom-social-icons">
					<a class="facebook" href="#">
						<span class="fa fa-facebook"></span>
					</a>
					<a class="twitter" href="#">
						<span class="fa fa-twitter"></span>
					</a>
					<a class="pinterest" href="#">
						<span class="fa fa-pinterest-p"></span>
					</a>
					<a class="linkedin" href="#">
						<span class="fa fa-linkedin"></span>
					</a>
				</div>
				<div class="header-top-righ">
					<a href="../add_edit_delete.rolyn/login.php">
						<span class="fa fa-sign-out" aria-hidden="true"></span>Login</a>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
	<div class="header">
		<div class="content white">
			<nav class="navbar navbar-default">
				<div class="container">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<a class="navbar-brand" href="index.html">
							<h1>
								<span class="fa fa-leanpub" aria-hidden="true"></span>Best Study
								<label>Education & Institutions</label>
							</h1>
						</a>
					</div>
					<!--/.navbar-header-->
					<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
						<nav class="link-effect-2" id="link-effect-2">
							<ul class="nav navbar-nav">
								<li>
									<a href="index.html" class="effect-3">Search Records</a>
								</li>

							</ul>
						</nav>
					</div>
					<!--/.navbar-collapse-->
					<!--/.navbar-->
				</div>
			</nav>
		</div>
	</div>
	<!-- banner -->
	<div class="inner_page_agile">

	</div>
	<!--//banner -->
	<!-- short-->
	<div class="services-breadcrumb">
		<div class="inner_breadcrumb">
			<ul class="short_ls">
				<li>
					<a href="index.html">Home</a>
					<span>| |</span>
				</li>
				<li>Join Us</li>
			</ul>
		</div>
	</div>
	<!-- //short-->
	<div class="register-form-main">
		<div class="container">
			<div class="title-div">
				<h3 class="tittle">
					<span>S</span>TUDENT
					<span>I</span>NFORMATION
					<span>S</span>YSTEM					
				</h3>
				<div class="tittle-style">

				</div>
			</div>
<!-- SEARCH ENGINE START-->



<?php

echo"<center>";
 echo"<form method='POST' action='' name='reg' onSubmit='return validate()'>";
echo"<table border='5' bgcolor='pink'><br><br></center>";

echo"<tr><td>
<center><table bgcolor='pink'>
<tr><td width='250'><b>Select Any One:<select name='sel'><option>Select Category</option>";

  echo"<option value='fname'>FIRST NAME</option>";
  echo"<option value='lname'>LAST NAME</option>";
  echo"<option value='mname'>MIDDLE NAME</option>";  
  echo"<option value='mn'>MATRIC NO</option>";
  echo"<option value='school'>INSTITUTION</option>";
  echo"<option value='phone'>PHONE</option>";
  echo"<option value='mail'>EMAIL</option>";
  echo"<option value='year'>YEAR</option>  
<td><input type='text' name='ty'><input type='submit' name='se' value='search'>";
echo"</tr></td></table>";
echo"</td></tr></table></center></form>
</body></html>";

 require'db_conn.php';

 $sel=$_POST['sel'];
   $ty=$_POST['ty'];

if(isset($_POST['se']))
 {

  if($sel=="fname")
  {
$q1=mysql_query("select* from bhup where fname='$ty'");
echo"<center><table border='1' width='80%'>";

  while($rows=mysql_fetch_array($q1,MYSQL_ASSOC))
{
 $me=$rows['mname'];
 $year=$rows['year'];
 $fn=$rows['fname'];
 $ln=$rows['lname'];
 $sch=$rows['school'];
 $mn=$rows['mn'];
 $ph=$rows['phone'];
 $dob=$rows['dob'];
 $email=$rows['mail'];
 $loc=$rows['location'];   
   

 echo"<tr><td colspan='3'><center>_________________________________________________________________________</center></td></tr>
<td width='10%' rowspan='6'>
<center><img src='../add_edit_delete.rolyn/upload/$loc' width='150px' style='border:1px solid #333333;'></td/></center></td/>
<td width='20%'>FIRST NAME</td><td width='50%'>$fn</td></tr><tr>
<td width='20%'>MIDDLE NAME</td><td width='50%'>$me</td></tr><tr>
<td width='20%'>LAST NAME</td><td width='50%'>$ln</td></tr><tr>
<td width='20%'>INSTITUTION</td><td width='50%'>$sch</td></tr><tr>
<td width='20%'>MATRIC NUMBER</td><td width='50%'>$mn</td></tr><tr>
<td width='20%'>GRADUATING YEAR</td><td width='50%'>$year</td></tr><br />";

}
 echo"</center>";
 
}
 
   if($sel=="lname")
  {
$q2=mysql_query("select* from bhup where lname='$ty'");
echo"<center><table border='1' width='80%'>";

  while($rows=mysql_fetch_array($q2,MYSQL_ASSOC))
{
 $me=$rows['mname'];
 $year=$rows['year'];
 $fn=$rows['fname'];
 $ln=$rows['lname'];
 $sch=$rows['school'];
 $mn=$rows['mn'];
 $ph=$rows['phone'];
 $dob=$rows['dob'];
 $email=$rows['mail'];
 $loc=$rows['location'];   
   

 echo"<tr><td colspan='3'><center>_________________________________________________________________________</center></td></tr>
<td width='10%' rowspan='6'>
<center><img src='../add_edit_delete.rolyn/upload/$loc' width='150px' style='border:1px solid #333333;'></td/></center>
 </td>
<td width='20%'>FIRST NAME</td><td width='50%'>$fn</td></tr><tr>
<td width='20%'>MIDDLE NAME</td><td width='50%'>$me</td></tr><tr>
<td width='20%'>LAST NAME</td><td width='50%'>$ln</td></tr><tr>
<td width='20%'>INSTITUTION</td><td width='50%'>$sch</td></tr><tr>
<td width='20%'>MATRIC NUMBER</td><td width='50%'>$mn</td></tr><tr>
<td width='20%'>GRADUATING YEAR</td><td width='50%'>$year</td></tr><br />";

}
 echo"</center>";
}

   if($sel=="mname")
  {
$q3=mysql_query("select* from bhup where mname='$ty'");
echo"<center><table border='1' width='80%'>";

  while($rows=mysql_fetch_array($q3,MYSQL_ASSOC))
{
 $me=$rows['mname'];
 $year=$rows['year'];
 $fn=$rows['fname'];
 $ln=$rows['lname'];
 $sch=$rows['school'];
 $mn=$rows['mn'];
 $ph=$rows['phone'];
 $dob=$rows['dob'];
 $email=$rows['mail'];
 $loc=$rows['location'];   
   

 echo"<tr><td colspan='3'><center>_________________________________________________________________________</center></td></tr>
<td width='10%' rowspan='6'>
<center><img src='../add_edit_delete.rolyn/upload/$loc' width='150px' style='border:1px solid #333333;'></td/></center> 	
 </td>
<td width='20%'>FIRST NAME</td><td width='50%'>$fn</td></tr><tr>
<td width='20%'>MIDDLE NAME</td><td width='50%'>$me</td></tr><tr>
<td width='20%'>LAST NAME</td><td width='50%'>$ln</td></tr><tr>
<td width='20%'>INSTITUTION</td><td width='50%'>$sch</td></tr><tr>
<td width='20%'>MATRIC NUMBER</td><td width='50%'>$mn</td></tr><tr>
<td width='20%'>GRADUATING YEAR</td><td width='50%'>$year</td></tr><br />";

}
 echo"</center>";
}

 if($sel=="mn")
  {
$q4=mysql_query("select* from bhup where mn='$ty'");
echo"<center><table border='1' width='80%'>";
  while($rows=mysql_fetch_array($q4,MYSQL_ASSOC))
{
 $me=$rows['mname'];
 $year=$rows['year'];
 $fn=$rows['fname'];
 $ln=$rows['lname'];
 $sch=$rows['school'];
 $mn=$rows['mn'];
 $ph=$rows['phone'];
 $dob=$rows['dob'];
 $email=$rows['mail'];
 $loc=$rows['location'];   
   

 echo"<tr><td colspan='3'><center>_________________________________________________________________________</center></td></tr>
<td width='10%' rowspan='6'>
<center><img src='../add_edit_delete.rolyn/upload/$loc' width='150px' style='border:1px solid #333333;'></td/></center> 	
 </td>
<td width='20%'>FIRST NAME</td><td width='50%'>$fn</td></tr><tr>
<td width='20%'>MIDDLE NAME</td><td width='50%'>$me</td></tr><tr>
<td width='20%'>LAST NAME</td><td width='50%'>$ln</td></tr><tr>
<td width='20%'>INSTITUTION</td><td width='50%'>$sch</td></tr><tr>
<td width='20%'>MATRIC NUMBER</td><td width='50%'>$mn</td></tr><tr>
<td width='20%'>GRADUATING YEAR</td><td width='50%'>$year</td></tr><br />";

}
 echo"</center>";
}

if($sel=="school")
  {
$q5=mysql_query("select* from bhup where school='$ty'");
echo"<center><table border='1' width='80%'>";

  while($rows=mysql_fetch_array($q5,MYSQL_ASSOC))
{
 $me=$rows['mname'];
 $year=$rows['year'];
 $fn=$rows['fname'];
 $ln=$rows['lname'];
 $sch=$rows['school'];
 $mn=$rows['mn'];
 $ph=$rows['phone'];
 $dob=$rows['dob'];
 $email=$rows['mail'];
 $loc=$rows['location'];   
   

 echo"<tr><td colspan='3'><center>_________________________________________________________________________</center></td></tr>
<td width='10%' rowspan='6'>
<center><img src='../add_edit_delete.rolyn/upload/$loc' width='150px' style='border:1px solid #333333;'></td/></center> 	
 </td>
<td width='20%'>FIRST NAME</td><td width='50%'>$fn</td></tr><tr>
<td width='20%'>MIDDLE NAME</td><td width='50%'>$me</td></tr><tr>
<td width='20%'>LAST NAME</td><td width='50%'>$ln</td></tr><tr>
<td width='20%'>INSTITUTION</td><td width='50%'>$sch</td></tr><tr>
<td width='20%'>MATRIC NUMBER</td><td width='50%'>$mn</td></tr><tr>
<td width='20%'>GRADUATING YEAR</td><td width='50%'>$year</td></tr><br />";

}
 echo"</center>";
}

if($sel=="phone")
  {
$q6=mysql_query("select* from bhup where phone='$ty'");
echo"<center><table border='1' width='80%'>";

  while($rows=mysql_fetch_array($q6,MYSQL_ASSOC))
{
 $me=$rows['mname'];
 $year=$rows['year'];
 $fn=$rows['fname'];
 $ln=$rows['lname'];
 $sch=$rows['school'];
 $mn=$rows['mn'];
 $ph=$rows['phone'];
 $dob=$rows['dob'];
 $email=$rows['mail'];
 $loc=$rows['location'];   
   

 echo"<tr><td colspan='3'><center>_________________________________________________________________________</center></td></tr>
<td width='10%' rowspan='6'>
<center><img src='../add_edit_delete.rolyn/upload/$loc' width='150px' style='border:1px solid #333333;'></td/></center> 	
 </td>
<td width='20%'>FIRST NAME</td><td width='50%'>$fn</td></tr><tr>
<td width='20%'>MIDDLE NAME</td><td width='50%'>$me</td></tr><tr>
<td width='20%'>LAST NAME</td><td width='50%'>$ln</td></tr><tr>
<td width='20%'>INSTITUTION</td><td width='50%'>$sch</td></tr><tr>
<td width='20%'>MATRIC NUMBER</td><td width='50%'>$mn</td></tr><tr>
<td width='20%'>GRADUATING YEAR</td><td width='50%'>$year</td></tr><br />";

}
 echo"</center>";
}

if($sel=="mail")
  {
$q7=mysql_query("select* from bhup where mail='$ty'");
echo"<center><table border='1' width='80%'>";

  while($rows=mysql_fetch_array($q7,MYSQL_ASSOC))
{
 $me=$rows['mname'];
 $year=$rows['year'];
 $fn=$rows['fname'];
 $ln=$rows['lname'];
 $sch=$rows['school'];
 $mn=$rows['mn'];
 $ph=$rows['phone'];
 $dob=$rows['dob'];
 $email=$rows['mail'];
 $loc=$rows['location'];   
   

 echo"<tr><td colspan='3'><center>_________________________________________________________________________</center></td></tr>
<td width='10%' rowspan='6'>
<center><img src='../add_edit_delete.rolyn/upload/$loc' width='150px' style='border:1px solid #333333;'></td/></center> 	
 </td>
<td width='20%'>FIRST NAME</td><td width='50%'>$fn</td></tr><tr>
<td width='20%'>MIDDLE NAME</td><td width='50%'>$me</td></tr><tr>
<td width='20%'>LAST NAME</td><td width='50%'>$ln</td></tr><tr>
<td width='20%'>INSTITUTION</td><td width='50%'>$sch</td></tr><tr>
<td width='20%'>MATRIC NUMBER</td><td width='50%'>$mn</td></tr><tr>
<td width='20%'>GRADUATING YEAR</td><td width='50%'>$year</td></tr><br />";

}
 echo"</center>";
}

if($sel=="year")
  {
$q8=mysql_query("select* from bhup where year='$ty'");
echo"<center><table border='1' width='80%'>";

  while($rows=mysql_fetch_array($q8,MYSQL_ASSOC))
{
 $me=$rows['mname'];
 $year=$rows['year'];
 $fn=$rows['fname'];
 $ln=$rows['lname'];
 $sch=$rows['school'];
 $mn=$rows['mn'];
 $ph=$rows['phone'];
 $dob=$rows['dob'];
 $email=$rows['mail'];
 $loc=$rows['location'];   
   

 echo"<tr><td colspan='3'><center>_________________________________________________________________________</center></td></tr>
<td width='10%' rowspan='6'>
<center><img src='../add_edit_delete.rolyn/upload/$loc' width='150px' style='border:1px solid #333333;'></td/></center> 	
 </td>
<td width='20%'>FIRST NAME</td><td width='50%'>$fn</td></tr><tr>
<td width='20%'>MIDDLE NAME</td><td width='50%'>$me</td></tr><tr>
<td width='20%'>LAST NAME</td><td width='50%'>$ln</td></tr><tr>
<td width='20%'>INSTITUTION</td><td width='50%'>$sch</td></tr><tr>
<td width='20%'>MATRIC NUMBER</td><td width='50%'>$mn</td></tr><tr>
<td width='20%'>GRADUATING YEAR</td><td width='50%'>$year</td></tr><br />";

}
 echo"</center>";
}

}
if(isset($_POST['se1']))
 {
$q9=mysql_query("select* from bhup");
echo"<center><table border='1' width='80%'>";

  while($rows=mysql_fetch_array($q9,MYSQL_ASSOC))
{
 $me=$rows['mname'];
 $year=$rows['year'];
 $fn=$rows['fname'];
 $ln=$rows['lname'];
 $sch=$rows['school'];
 $mn=$rows['mn'];
 $ph=$rows['phone'];
 $dob=$rows['dob'];
 $email=$rows['mail'];
 $loc=$rows['location'];   
   

 echo"<tr><td colspan='3'><center>_________________________________________________________________________</center></td></tr>
<td width='10%' rowspan='6'>
<center><img src='../add_edit_delete.rolyn/upload/$loc' width='150px' style='border:1px solid #333333;'></td/></center> 	
 </td>
<td width='20%'>FIRST NAME</td><td width='50%'>$fn</td></tr><tr>
<td width='20%'>MIDDLE NAME</td><td width='50%'>$me</td></tr><tr>
<td width='20%'>LAST NAME</td><td width='50%'>$ln</td></tr><tr>
<td width='20%'>INSTITUTION</td><td width='50%'>$sch</td></tr><tr>
<td width='20%'>MATRIC NUMBER</td><td width='50%'>$mn</td></tr><tr>
<td width='20%'>GRADUATING YEAR</td><td width='50%'>$year</td></tr><br />";

}
 echo"</center>";
}

echo"Developed by <a href='https://www.gswapps.com'>Gswapps</a>";

?>

<!-- SEARCH ENGINE END//-->
</div></div>
<br /><br />

	<!-- js files -->
	<!-- js -->
	<script src="js/jquery-2.1.4.min.js"></script>
	<!-- bootstrap -->
	<script src="js/bootstrap.js"></script>
	<!-- Calendar -->
	<link rel="stylesheet" href="css/jquery-ui.css" />
	<script src="js/jquery-ui.js"></script>
	<script>
		$(function () {
			$("#datepicker,#datepicker1,#datepicker2,#datepicker3").datepicker();
		});
	</script>
	<!-- //Calendar -->
	<!-- smooth scrolling -->
	<script src="js/SmoothScroll.min.js"></script>
	<script src="js/move-top.js"></script>
	<script src="js/easing.js"></script>
	<!-- here stars scrolling icon -->
	<script>
		$(document).ready(function () {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
				};
			*/

			$().UItoTop({
				easingType: 'easeOutQuart'
			});

		});
	</script>
	<!-- //here ends scrolling icon -->
	<!-- smooth scrolling -->
	<!-- //js-files -->

</body>

</html>